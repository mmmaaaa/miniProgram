export default {
    host:'http://localhost:3000',
    mobileHost:'http://mjr10086.cn1.utools.club'
}
